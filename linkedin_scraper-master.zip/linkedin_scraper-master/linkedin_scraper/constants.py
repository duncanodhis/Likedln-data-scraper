VERIFY_LOGIN_ID = "global-nav-search"
REMEMBER_PROMPT = 'remember-me-prompt__form-primary'
