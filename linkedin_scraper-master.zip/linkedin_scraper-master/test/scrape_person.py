from linkedin_scraper import Person

rick_fox = Person("https://www.linkedin.com/in/rifox?trk=pub-pbmap")
iggy = Person("https://www.linkedin.com/in/andre-iguodala-65b48ab5")
Anirudra = Person("https://in.linkedin.com/in/anirudra-choudhury-109635b1")
